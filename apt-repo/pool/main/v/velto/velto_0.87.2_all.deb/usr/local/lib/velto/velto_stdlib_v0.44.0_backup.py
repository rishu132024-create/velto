import math
import random


class StdLibError(Exception):
    pass


def builtin_len(arguments):
    if len(arguments) != 1:
        raise StdLibError("len() expects 1 argument")

    try:
        return len(arguments[0])
    except TypeError:
        raise StdLibError("Object has no length")


def builtin_str(arguments):
    if len(arguments) != 1:
        raise StdLibError("str() expects 1 argument")

    return str(arguments[0])


def builtin_int(arguments):
    if len(arguments) != 1:
        raise StdLibError("int() expects 1 argument")

    try:
        return int(arguments[0])
    except (ValueError, TypeError):
        raise StdLibError("Cannot convert value to int")


def builtin_float(arguments):
    if len(arguments) != 1:
        raise StdLibError("float() expects 1 argument")

    try:
        return float(arguments[0])
    except (ValueError, TypeError):
        raise StdLibError("Cannot convert value to float")


def builtin_abs(arguments):
    if len(arguments) != 1:
        raise StdLibError("abs() expects 1 argument")

    try:
        return abs(arguments[0])
    except TypeError:
        raise StdLibError("Invalid value for abs()")


def builtin_min(arguments):
    if len(arguments) == 0:
        raise StdLibError("min() expects at least 1 argument")

    try:
        return min(arguments)
    except TypeError:
        raise StdLibError("Invalid values for min()")


def builtin_max(arguments):
    if len(arguments) == 0:
        raise StdLibError("max() expects at least 1 argument")

    try:
        return max(arguments)
    except TypeError:
        raise StdLibError("Invalid values for max()")


def builtin_range(arguments):
    if len(arguments) < 1 or len(arguments) > 3:
        raise StdLibError(
            "range() expects 1 to 3 arguments"
        )

    try:
        return list(range(*arguments))
    except (TypeError, ValueError):
        raise StdLibError(
            "Invalid arguments for range()"
        )


def builtin_sqrt(arguments):
    if len(arguments) != 1:
        raise StdLibError("sqrt() expects 1 argument")

    try:
        return math.sqrt(arguments[0])
    except (TypeError, ValueError):
        raise StdLibError("Invalid value for sqrt()")


def builtin_power(arguments):
    if len(arguments) != 2:
        raise StdLibError("power() expects 2 arguments")

    try:
        return arguments[0] ** arguments[1]
    except (TypeError, ValueError):
        raise StdLibError("Invalid values for power()")


def builtin_floor(arguments):
    if len(arguments) != 1:
        raise StdLibError("floor() expects 1 argument")

    try:
        return math.floor(arguments[0])
    except (TypeError, ValueError):
        raise StdLibError("Invalid value for floor()")


def builtin_ceil(arguments):
    if len(arguments) != 1:
        raise StdLibError("ceil() expects 1 argument")

    try:
        return math.ceil(arguments[0])
    except (TypeError, ValueError):
        raise StdLibError("Invalid value for ceil()")


def builtin_sin(arguments):
    if len(arguments) != 1:
        raise StdLibError("sin() expects 1 argument")

    try:
        return math.sin(arguments[0])
    except (TypeError, ValueError):
        raise StdLibError("Invalid value for sin()")


def builtin_cos(arguments):
    if len(arguments) != 1:
        raise StdLibError("cos() expects 1 argument")

    try:
        return math.cos(arguments[0])
    except (TypeError, ValueError):
        raise StdLibError("Invalid value for cos()")


def builtin_tan(arguments):
    if len(arguments) != 1:
        raise StdLibError("tan() expects 1 argument")

    try:
        return math.tan(arguments[0])
    except (TypeError, ValueError):
        raise StdLibError("Invalid value for tan()")


def builtin_round(arguments):
    if len(arguments) not in (1, 2):
        raise StdLibError(
            "round() expects 1 or 2 arguments"
        )

    try:
        return round(*arguments)
    except (TypeError, ValueError):
        raise StdLibError(
            "Invalid arguments for round()"
        )


def builtin_random(arguments):
    if len(arguments) != 0:
        raise StdLibError(
            "random() expects 0 arguments"
        )

    return random.random()


def builtin_randint(arguments):
    if len(arguments) != 2:
        raise StdLibError(
            "randint() expects 2 arguments"
        )

    try:
        return random.randint(
            arguments[0],
            arguments[1]
        )
    except (TypeError, ValueError):
        raise StdLibError(
            "Invalid arguments for randint()"
        )


def builtin_choice(arguments):
    if len(arguments) != 1:
        raise StdLibError(
            "choice() expects 1 argument"
        )

    try:
        return random.choice(arguments[0])
    except (IndexError, TypeError):
        raise StdLibError(
            "Cannot choose from this value"
        )


def builtin_shuffle(arguments):
    if len(arguments) != 1:
        raise StdLibError(
            "shuffle() expects 1 argument"
        )

    value = arguments[0]

    if not isinstance(value, list):
        raise StdLibError(
            "shuffle() requires a list"
        )

    random.shuffle(value)

    return value


BUILTINS = {
    "len": builtin_len,
    "str": builtin_str,
    "int": builtin_int,
    "float": builtin_float,
    "abs": builtin_abs,
    "min": builtin_min,
    "max": builtin_max,
    "range": builtin_range,
    "sqrt": builtin_sqrt,
    "power": builtin_power,
    "floor": builtin_floor,
    "ceil": builtin_ceil,
    "sin": builtin_sin,
    "cos": builtin_cos,
    "tan": builtin_tan,
    "round": builtin_round,
    "random": builtin_random,
    "randint": builtin_randint,
    "choice": builtin_choice,
    "shuffle": builtin_shuffle
}
